# http://blog.ablepear.com/2012/10/bundling-python-files-into-stand-alone.html

def main():
    print("Hello, welcome to my command line!!")

if __name__ == '__main__':
    main()
